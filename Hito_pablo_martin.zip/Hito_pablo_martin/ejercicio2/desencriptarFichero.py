#Este archivo se basa en la desencriptación de los archivos que habíamos encriptado anteriormente

#En primer lugar, usaremos el método Fernet de la librería cryptography
#Además de emplementar la librería os que nos permitirá encriptar los archivos
from cryptography.fernet import Fernet
import os

#Función para obtener la contraseña/clave que hemos utilizado anteriormente en el cifrado de los archivos
def cargar_password():
    return open('key.key', 'rb').read() #Leemos la Clave

#Definimos lo elementos que queremos desencriptar y la clave para desencriptar
def decrypt(items, key):
    f = Fernet(key) #Clave
    for item in items: #Iteramos los Elementos
        with open(item, 'rb') as file:
            encrypted_data = file.read()
        decrypted_data = f.decrypt(encrypted_data) #En este paso, desencriptamos el archivo
        with open(item, 'wb') as file:
            file.write(decrypted_data) #Cargamos los datos encriptados y los desencriptamos para mostrarlo

#A continuación, el método siguiente se usa para comprobar que se ha desencriptado correctamente
if __name__ == '__main__':
    #Directorio que vamos a encriptar
    path_to_encrypt = "archivo"
    #Eliminamos el archivo que habíamos generado para mostrarle un mensaje al propietario de los Archivos
    os.remove(path_to_encrypt+"\\"+'archivoRescate.txt')

    items = os.listdir(path_to_encrypt)
    full_path = [path_to_encrypt+"\\"+item for item in items]

    key = cargar_password() #Volvemos a Cargar la contraseña/clave
    decrypt(full_path, key) #Y volvemos a llamar al método decrypt para desemcriptar todos los archivos