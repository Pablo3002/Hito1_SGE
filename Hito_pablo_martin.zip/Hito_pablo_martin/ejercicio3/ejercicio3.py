import pandas as pd #Importo la Librería pandas para la lectura del Archivo CSV
import matplotlib.pyplot as plt #Importo matplotlib para realizar el Gráfico

"""Al ser la lectura de grandes cantidades de datos que escogido un archivo csv con más de 10.000 registros, pare ser más concreto, el archivo
tiene 19.239 registros únicos"""

datos = pd.read_csv('players_fifa22.csv')#Leo el Archivo csv

media = datos.Overall #Creo una variable para almacenar la Media de Casa Jugador

fig, ax = plt.subplots() #Con este método agregamos la figura a la cuadrícula indicada

ax.violinplot([media]) #Le paso la Media que va a ser los datos con los que voy a realizar la gráfica
ax.set_title("Grafica de la Media de los Jugadores") #Le inserto el Título de la Gráfica de Violín
plt.show() #Visualizo el Gráfico

"""A continuación, el siguiente gráfico es un gráfico en 3 Dimensiones donde se debe de meter 3 Columnas del Archivo que van a ser
la Edad, la Media y la Media Potencial que tiene el Jugador, en este caso lo voy a realizar con los 5 primeros registros ya que
así será más facil el entendimiento del gráfico"""

x = datos.Age.head(5)
y = datos.Overall.head(5)
z = datos.Potential.head(5)

figura = plt.figure() #Creamos la Gráfica
ax=figura.add_subplot(111, projection="3d") #Add_subplot su funcion es subdividir la figura

#Pongo una label a cada ejer para el mejor entendimiento del gráfico
ax.set_xlabel("Edad")
ax.set_ylabel("Media Jugador")
ax.set_zlabel("Potencial Jugador")

ax.scatter3D(x, y, z, c=z, cmap="Set1")#Tiene que ver con la dispersion(Diagrama de Puntos)
#Set1 tiene que ver con los colores de los elementos
plt.show()